import "./style.css";
import { SelectionManager } from "./ui-utils.js";
import { EvaluationManager } from "./evaluation-manager.js";

export interface Point {
  x: number;
  y: number;
}

function computeVariance(arr: number[]): number {
  if (!arr || arr.length === 0) return 0;
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  const variance = arr.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / arr.length;
  return variance / (mean || 1);
}

export interface DetectedShape {
  type: "circle" | "triangle" | "rectangle" | "pentagon" | "star";
  confidence: number;
  boundingBox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  center: Point;
  area: number;
}

export interface DetectionResult {
  shapes: DetectedShape[];
  processingTime: number;
  imageWidth: number;
  imageHeight: number;
}

export class ShapeDetector {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
  }

  async detectShapes(imageData: ImageData): Promise<DetectionResult> {
    const start = performance.now();
    const { width, height, data } = imageData;
    const gray = new Uint8ClampedArray(width * height);
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      gray[i / 4] = 0.299 * r + 0.587 * g + 0.114 * b;
    }
    const binary = new Uint8Array(width * height);
    for (let i = 0; i < gray.length; i++) {
      binary[i] = gray[i] < 128 ? 1 : 0;
    }
    const visited = new Uint8Array(width * height);
    const shapes: DetectedShape[] = [];
    const directions = [
      [-1, 0],
      [1, 0],
      [0, -1],
      [0, 1],
      [-1, -1],
      [-1, 1],
      [1, -1],
      [1, 1],
    ];
    const bfs = (sx: number, sy: number) => {
      const pixels: Point[] = [];
      const queue: [number, number][] = [[sx, sy]];
      visited[sy * width + sx] = 1;
      while (queue.length) {
        const [x, y] = queue.shift()!;
        pixels.push({ x, y });
        for (const [dx, dy] of directions) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
          const idx = ny * width + nx;
          if (!visited[idx] && binary[idx] === 1) {
            visited[idx] = 1;
            queue.push([nx, ny]);
          }
        }
      }
      return pixels;
    };
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        if (!visited[idx] && binary[idx] === 1) {
          const pixels = bfs(x, y);
          if (pixels.length < 30) continue;
          const xs = pixels.map((p) => p.x);
          const ys = pixels.map((p) => p.y);
          const minX = Math.min(...xs), maxX = Math.max(...xs);
          const minY = Math.min(...ys), maxY = Math.max(...ys);
          const w = maxX - minX + 1;
          const h = maxY - minY + 1;
          const cx = xs.reduce((a, b) => a + b, 0) / xs.length;
          const cy = ys.reduce((a, b) => a + b, 0) / ys.length;
          const area = pixels.length;
          const aspect = w / h;
          let type: DetectedShape["type"] = "circle";
          let confidence = 0.5;
          if (Math.abs(aspect - 1) < 0.15) {
            type = "circle";
            confidence = 0.75;
          }
          const cornerInfo = estimateCorners(pixels);
          const cornerCount = cornerInfo.count;
          const corners = cornerInfo.corners;
          const cornerAngles: number[] = [];
          const distancesFromCenter: number[] = [];
          if (corners.length > 0) {
            for (const p of corners) {
              const dx = p.x - cx;
              const dy = p.y - cy;
              const angle = Math.atan2(dy, dx);
              cornerAngles.push(angle);
              distancesFromCenter.push(Math.hypot(dx, dy));
            }
            for (let i = 0; i < cornerAngles.length; i++) {
              const next = cornerAngles[(i + 1) % cornerAngles.length];
              let diff = Math.abs(next - cornerAngles[i]);
              if (diff > Math.PI) diff = 2 * Math.PI - diff;
              cornerAngles[i] = diff;
            }
          }
          if (cornerCount <= 2) {
            type = "circle";
            confidence = Math.max(confidence, 0.9);
          } else if (cornerCount === 3) {
            type = "triangle";
            confidence = 0.95;
          } else if (cornerCount === 4) {
            type = "rectangle";
            confidence = 0.95;
          } else if (cornerCount === 5) {
            const angleVariance = computeVariance(cornerAngles);
            const distanceVariance = computeVariance(distancesFromCenter);
            const maxDistance = Math.max(...distancesFromCenter);
            const minDistance = Math.min(...distancesFromCenter);
            const distanceRatio = maxDistance / (minDistance || 1);
            const areaRatio = area / (w * h);
            if (angleVariance > 0.1 || distanceVariance > 0.1 || distanceRatio > 1.2 || areaRatio < 0.5) {
              type = "star";
              confidence = 0.92;
            } else {
              type = "pentagon";
              confidence = 0.95;
            }
          } else if (cornerCount >= 7 && cornerCount <= 12) {
            type = "star";
            confidence = 0.95;
          } else {
            if (Math.abs(aspect - 1) < 0.2 && area / (w * h) > 0.6) {
              type = "circle";
              confidence = 0.9;
            } else {
              if (cornerCount > 12) {
                type = "star";
                confidence = 0.9;
              } else {
                if (cornerCount === 6) {
                  type = "pentagon";
                  confidence = 0.8;
                } else if (cornerCount === 7) {
                  type = "star";
                  confidence = 0.85;
                }
              }
            }
          }
          shapes.push({
            type,
            confidence,
            area,
            center: { x: cx, y: cy },
            boundingBox: { x: minX, y: minY, width: w, height: h },
          });
        }
      }
    }
    const end = performance.now();
    return {
      shapes,
      processingTime: end - start,
      imageWidth: width,
      imageHeight: height,
    };
  }

  loadImage(file: File): Promise<ImageData> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        this.canvas.width = img.width;
        this.canvas.height = img.height;
        this.ctx.drawImage(img, 0, 0);
        const imageData = this.ctx.getImageData(0, 0, img.width, img.height);
        resolve(imageData);
      };
      img.onerror = reject;
      img.src = URL.createObjectURL(file);
    });
  }
}

class ShapeDetectionApp {
  private detector: ShapeDetector;
  private imageInput: HTMLInputElement;
  private resultsDiv: HTMLDivElement;
  private testImagesDiv: HTMLDivElement;
  private evaluateButton: HTMLButtonElement;
  private evaluationResultsDiv: HTMLDivElement;
  private selectionManager: SelectionManager;
  private evaluationManager: EvaluationManager;

  constructor() {
    const canvas = document.getElementById("originalCanvas") as HTMLCanvasElement;
    this.detector = new ShapeDetector(canvas);
    this.imageInput = document.getElementById("imageInput") as HTMLInputElement;
    this.resultsDiv = document.getElementById("results") as HTMLDivElement;
    this.testImagesDiv = document.getElementById("testImages") as HTMLDivElement;
    this.evaluateButton = document.getElementById("evaluateButton") as HTMLButtonElement;
    this.evaluationResultsDiv = document.getElementById("evaluationResults") as HTMLDivElement;
    this.selectionManager = new SelectionManager();
    this.evaluationManager = new EvaluationManager(this.detector, this.evaluateButton, this.evaluationResultsDiv);
    this.setupEventListeners();
    this.loadTestImages().catch(console.error);
  }

  private setupEventListeners(): void {
    this.imageInput.addEventListener("change", async (event) => {
      const file = (event.target as HTMLInputElement).files?.[0];
      if (file) {
        await this.processImage(file);
      }
    });
    this.evaluateButton.addEventListener("click", async () => {
      const selectedImages = this.selectionManager.getSelectedImages();
      await this.evaluationManager.runSelectedEvaluation(selectedImages);
    });
  }

  private async processImage(file: File): Promise<void> {
    try {
      this.resultsDiv.innerHTML = "<p>Processing...</p>";
      const imageData = await this.detector.loadImage(file);
      const results = await this.detector.detectShapes(imageData);
      this.displayResults(results);
    } catch (error) {
      this.resultsDiv.innerHTML = `<p>Error: ${error}</p>`;
    }
  }

  private displayResults(results: DetectionResult): void {
    const { shapes, processingTime } = results;
    let html = `
      <p><strong>Processing Time:</strong> ${processingTime.toFixed(2)}ms</p>
      <p><strong>Shapes Found:</strong> ${shapes.length}</p>
    `;
    if (shapes.length > 0) {
      html += "<h4>Detected Shapes:</h4><ul>";
      shapes.forEach((shape) => {
        html += `
          <li>
            <strong>${shape.type.charAt(0).toUpperCase() + shape.type.slice(1)}</strong><br>
            Confidence: ${(shape.confidence * 100).toFixed(1)}%<br>
            Center: (${shape.center.x.toFixed(1)}, ${shape.center.y.toFixed(1)})<br>
            Area: ${shape.area.toFixed(1)}px²
          </li>
        `;
      });
      html += "</ul>";
    } else {
      html += "<p>No shapes detected.</p>";
    }
    this.resultsDiv.innerHTML = html;
  }

  private async loadTestImages(): Promise<void> {
    try {
      const module = await import("./test-images-data.js");
      const testImages = module.testImages;
      const imageNames = module.getAllTestImageNames();
      let html =
        '<h4>Click to upload your own image or use test images for detection. Right-click test images to select/deselect for evaluation:</h4><div class="evaluation-controls"><button id="selectAllBtn">Select All</button><button id="deselectAllBtn">Deselect All</button><span class="selection-info">0 images selected</span></div><div class="test-images-grid">';
      html += `
        <div class="test-image-item upload-item" onclick="triggerFileUpload()">
          <div class="upload-icon">📁</div>
          <div class="upload-text">Upload Image</div>
          <div class="upload-subtext">Click to select file</div>
        </div>
      `;
      imageNames.forEach((imageName) => {
        const dataUrl = testImages[imageName];
        const displayName = imageName.replace(/[_-]/g, " ").replace(/\.(svg|png)$/i, "");
        html += `
          <div class="test-image-item" data-image="${imageName}" 
               onclick="loadTestImage('${imageName}', '${dataUrl}')" 
               oncontextmenu="toggleImageSelection(event, '${imageName}')">
            <img src="${dataUrl}" alt="${imageName}">
            <div>${displayName}</div>
          </div>
        `;
      });
      html += "</div>";
      this.testImagesDiv.innerHTML = html;
      this.selectionManager.setupSelectionControls();
      (window as any).loadTestImage = async (name: string, dataUrl: string) => {
        try {
          const response = await fetch(dataUrl);
          const blob = await response.blob();
          const file = new File([blob], name, { type: "image/svg+xml" });
          const imageData = await this.detector.loadImage(file);
          const results = await this.detector.detectShapes(imageData);
          this.displayResults(results);
        } catch (error) {
          console.error("Error loading test image:", error);
        }
      };
      (window as any).toggleImageSelection = (event: MouseEvent, imageName: string) => {
        event.preventDefault();
        this.selectionManager.toggleImageSelection(imageName);
      };
      (window as any).triggerFileUpload = () => {
        this.imageInput.click();
      };
    } catch (error) {
      this.testImagesDiv.innerHTML = `
        <p>Test images not available. Run 'node convert-svg-to-png.js' to generate test image data.</p>
        <p>SVG files are available in the test-images/ directory.</p>
      `;
    }
  }
}

function estimateCorners(points: Point[]): { count: number; corners: Point[] } {
  if (!points || points.length === 0) return { count: 0, corners: [] };
  const pointSet = new Set(points.map((p) => `${p.x},${p.y}`));
  const boundary: Point[] = [];
  for (const p of points) {
    let isBoundary = false;
    for (let dx = -1; dx <= 1 && !isBoundary; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        if (dx === 0 && dy === 0) continue;
        if (!pointSet.has(`${p.x + dx},${p.y + dy}`)) {
          isBoundary = true;
          break;
        }
      }
    }
    if (isBoundary) boundary.push(p);
  }
  if (boundary.length < 3) return { count: 0, corners: [] };
  const sorted = boundary.slice().sort((a, b) => (a.x === b.x ? a.y - b.y : a.x - b.x));
  const cross = (o: Point, a: Point, b: Point) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
  const buildHull = (pts: Point[]) => {
    const hull: Point[] = [];
    for (const p of pts) {
      while (hull.length >= 2 && cross(hull[hull.length - 2], hull[hull.length - 1], p) <= 0) {
        hull.pop();
      }
      hull.push(p);
    }
    return hull;
  };
  const lower = buildHull(sorted);
  const upper = buildHull(sorted.slice().reverse());
  const fullHull = lower.concat(upper.slice(1, -1));
  if (fullHull.length < 3) return { count: 0, corners: [] };
  const simplified = rdp(fullHull, 2.0);
  if (simplified.length < 3) return { count: 0, corners: simplified };
  const corners: Point[] = [];
  for (let i = 0; i < simplified.length; i++) {
    const a = simplified[(i - 1 + simplified.length) % simplified.length];
    const b = simplified[i];
    const c = simplified[(i + 1) % simplified.length];
    const abx = a.x - b.x;
    const aby = a.y - b.y;
    const cbx = c.x - b.x;
    const cby = c.y - b.y;
    const laba = Math.hypot(abx, aby);
    const lbca = Math.hypot(cbx, cby);
    if (laba === 0 || lbca === 0) continue;
    let cos = (abx * cbx + aby * cby) / (laba * lbca);
    cos = Math.max(-1, Math.min(1, cos));
    const angle = Math.acos(cos);
    if (angle < 2.4) corners.push(b);
  }
  return { count: corners.length, corners };
}

function rdp(points: Point[], epsilon: number): Point[] {
  if (points.length < 3) return points.slice();
  const getPerpDist = (p: Point, a: Point, b: Point) => {
    const num = Math.abs((b.y - a.y) * p.x - (b.x - a.x) * p.y + b.x * a.y - b.y * a.x);
    const den = Math.hypot(b.y - a.y, b.x - a.x);
    return den === 0 ? 0 : num / den;
  };
  let dmax = 0;
  let index = 0;
  for (let i = 1; i < points.length - 1; i++) {
    const d = getPerpDist(points[i], points[0], points[points.length - 1]);
    if (d > dmax) {
      index = i;
      dmax = d;
    }
  }
  if (dmax > epsilon) {
    const left = rdp(points.slice(0, index + 1), epsilon);
    const right = rdp(points.slice(index), epsilon);
    return left.slice(0, left.length - 1).concat(right);
  }
  return [points[0], points[points.length - 1]];
}

document.addEventListener("DOMContentLoaded", () => {
  new ShapeDetectionApp();
});
